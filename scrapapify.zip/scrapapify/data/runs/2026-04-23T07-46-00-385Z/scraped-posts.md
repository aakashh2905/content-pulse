# Scraped Posts

Mode: **demo**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | instagram_creator_6 | trending content angle 6 | 179,292 | 6.05% | VIRAL |
| instagram | instagram_creator_2 | trending content angle 2 | 173,302 | 3.50% | VIRAL |
| instagram | instagram_creator_3 | Marketting content angle 3 | 162,014 | 2.39% | VIRAL |
| instagram | instagram_creator_1 | Marketting content angle 1 | 161,077 | 10.84% | VIRAL |
| instagram | instagram_creator_4 | trending content angle 4 | 153,969 | 9.54% | VIRAL |
| x | x_creator_5 | Marketting content angle 5 | 143,624 | 5.09% | VIRAL |
| x | x_creator_2 | trending content angle 2 | 139,029 | 16.98% | VIRAL |
| youtube | youtube_creator_1 | Marketting content angle 1 | 135,162 | 19.37% | VIRAL |
| x | x_creator_3 | Marketting content angle 3 | 72,822 | 16.13% | VIRAL |
| instagram | instagram_creator_5 | Marketting content angle 5 | 72,633 | 33.73% | VIRAL |
| youtube | youtube_creator_4 | trending content angle 4 | 72,034 | 35.21% | VIRAL |
| youtube | youtube_creator_2 | trending content angle 2 | 70,604 | 32.94% | VIRAL |
| youtube | youtube_creator_6 | trending content angle 6 | 67,352 | 27.86% | VIRAL |
| youtube | youtube_creator_3 | Marketting content angle 3 | 65,700 | 7.86% | VIRAL |
| x | x_creator_1 | Marketting content angle 1 | 39,900 | 42.28% | VIRAL |
| x | x_creator_6 | trending content angle 6 | 31,358 | 43.04% | VIRAL |
| x | x_creator_4 | trending content angle 4 | 24,346 | 98.32% | VIRAL |
| youtube | youtube_creator_5 | Marketting content angle 5 | 23,834 | 51.73% | VIRAL |
