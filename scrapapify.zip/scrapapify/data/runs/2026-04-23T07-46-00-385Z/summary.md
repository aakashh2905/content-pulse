# Codex Content System Run

Run ID: `2026-04-23T07-46-00-385Z`

## Inputs
- Skill location: C:\Users\Win 10\.codex\skills
- UI type: simple local web page
- Scraping method: Apify + OpenAI
- Output formats: markdown table, json
- Keywords: Marketting, trending
- Competitors: none
- Platforms: instagram, youtube, x
- Lookback: 30 days

## Outputs
- Scraped posts: 18
- Ranked topics: 2
- Script topic: trending
- Hooks generated: 5
