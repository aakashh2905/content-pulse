# Validation Report

**Recommendation:** trending - Recommendation generated from local score weights because OpenAI is not configured.

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| trending | 9 | 101,254 | 30.38% | repeat viral signal |
| Marketting | 9 | 97,418 | 21.04% | repeat viral signal |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| x post | 6 | 698 |
| youtube short | 6 | 635 |
| instagram reel | 6 | 568 |
