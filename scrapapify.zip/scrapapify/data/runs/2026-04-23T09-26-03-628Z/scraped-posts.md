# Scraped Posts

Mode: **mixed**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| youtube | youtube_creator_1 | Hustle content angle 1 | 164,635 | 10.64% | VIRAL |
| youtube | youtube_creator_2 | AI content angle 2 | 148,804 | 14.09% | VIRAL |
| youtube | youtube_creator_6 | AI content angle 6 | 101,336 | 9.75% | VIRAL |
| x | x_creator_1 | Hustle content angle 1 | 101,162 | 6.63% | VIRAL |
| youtube | youtube_creator_3 | Hustle content angle 3 | 87,215 | 14.43% | VIRAL |
| x | x_creator_4 | AI content angle 4 | 85,188 | 12.64% | VIRAL |
| x | x_creator_6 | AI content angle 6 | 84,506 | 10.15% | VIRAL |
| x | x_creator_5 | Hustle content angle 5 | 78,802 | 7.85% | VIRAL |
| x | x_creator_2 | AI content angle 2 | 76,099 | 5.20% | VIRAL |
| youtube | youtube_creator_4 | AI content angle 4 | 72,758 | 17.64% | VIRAL |
| x | x_creator_3 | Hustle content angle 3 | 46,013 | 38.13% | VIRAL |
| youtube | youtube_creator_5 | Hustle content angle 5 | 44,947 | 55.46% | VIRAL |
| instagram | unknown | - | 0 | 0.00% |  |
