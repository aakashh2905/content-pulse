# Codex Content System Run

Run ID: `2026-04-23T09-26-03-628Z`

## Inputs
- Skill location: C:\Users\Win 10\.codex\skills
- UI type: simple local web page
- Scraping method: Apify + OpenAI
- Output formats: markdown table, json
- Keywords: Hustle, AI
- Competitors: none
- Platforms: instagram, youtube, x
- Lookback: 7 days

## Outputs
- Scraped posts: 13
- Ranked topics: 2
- Script topic: Hustle
- Hooks generated: 5
