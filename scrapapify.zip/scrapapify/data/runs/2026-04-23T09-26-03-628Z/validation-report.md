# Validation Report

**Recommendation:** Hustle - Recommendation fell back to local heuristics after JSON parsing failed.

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| AI | 6 | 94,782 | 11.58% | repeat viral signal |
| Hustle | 6 | 87,129 | 22.19% | repeat viral signal |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| youtube short | 6 | 981 |
| x post | 6 | 660 |
