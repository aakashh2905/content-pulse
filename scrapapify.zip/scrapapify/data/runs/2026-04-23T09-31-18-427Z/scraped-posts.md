# Scraped Posts

Mode: **demo**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| youtube | youtube_creator_2 | AI agents content angle 2 | 179,454 | 13.16% | VIRAL |
| youtube | youtube_creator_1 | AI tools content angle 1 | 160,390 | 9.27% | VIRAL |
| instagram | instagram_creator_1 | AI tools content angle 1 | 125,465 | 13.19% | VIRAL |
| instagram | instagram_creator_2 | AI agents content angle 2 | 94,972 | 25.63% | VIRAL |
