# Validation Report

**Recommendation:** AI agents - Recommendation generated from local score weights because OpenAI is not configured.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |
| Tool Spotlight | 4 | 140,070 | 15.31% |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| AI tools | 2 | 142,928 | 11.23% |  |
| AI agents | 2 | 137,213 | 19.39% |  |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| instagram reel | 2 | 1,360 |
| youtube short | 2 | 563 |
