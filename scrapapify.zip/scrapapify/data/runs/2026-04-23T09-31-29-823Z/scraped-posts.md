# Scraped Posts

Mode: **mixed**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| youtube | youtube_creator_2 | AI agents content angle 2 | 179,454 | 13.16% | VIRAL |
| youtube | youtube_creator_1 | AI tools content angle 1 | 160,390 | 9.27% | VIRAL |
| instagram | unknown | - | 0 | 0.00% |  |
