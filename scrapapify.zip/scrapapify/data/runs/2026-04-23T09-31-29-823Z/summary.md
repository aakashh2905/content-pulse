# Codex Content System Run

Run ID: `2026-04-23T09-31-29-823Z`

## Inputs
- Skill location: C:\Users\Win 10\.codex\skills
- UI type: simple local web page
- Scraping method: Apify + OpenAI
- Output formats: markdown table, json
- Keywords: AI tools, AI agents
- Competitors: none
- Platforms: instagram, youtube
- Lookback: 7 days

## Outputs
- Scraped posts: 3
- Content buckets: 1
- Ranked topics: 2
- Script topic: AI agents
- Hooks generated: 5
