# Validation Report

**Recommendation:** AI agents - Recommendation fell back to local heuristics after JSON parsing failed.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |
| Tool Spotlight | 2 | 169,922 | 11.22% |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| AI agents | 1 | 179,454 | 13.16% |  |
| AI tools | 1 | 160,390 | 9.27% |  |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| youtube short | 2 | 563 |
