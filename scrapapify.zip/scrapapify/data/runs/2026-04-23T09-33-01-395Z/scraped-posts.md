# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| youtube | unknown | AI Agents, Clearly Explained | 4,189,675 | 2.43% | VIRAL |
| youtube | unknown | You’re not behind (yet): How to learn AI in 18 minutes | 1,259,840 | 3.49% | VIRAL |
| youtube | unknown | 7 Best AI Tools You NEED to Try (Free & Powerful | 658,040 | 1.67% | VIRAL |
| youtube | unknown | 5 AI Tools I Use Every Day | 599,321 | 3.67% | VIRAL |
| youtube | unknown | 7 AI tools you NEED to try | 425,896 | 2.35% | VIRAL |
| youtube | unknown | Why is an AI agent managing this store in San Francisco | 263,414 | 2.39% | VIRAL |
| youtube | unknown | From Zero to Your First AI Agent In 12 Minutes (No Coding) | 13,272 | 0.00% |  |
| youtube | unknown | CLI or MCP | 2,576 | 6.13% | VIRAL |
| instagram | unknown | - | 0 | 0.00% |  |
