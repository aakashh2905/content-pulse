# Validation Report

**Recommendation:** AI agents - Recommendation fell back to local heuristics after JSON parsing failed.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |
| Tutorial / Walkthrough | 2 | 2,724,758 | 2.96% |
| Tool Spotlight | 2 | 512,609 | 3.01% |
| Results / Case Study | 1 | 263,414 | 2.39% |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| AI agents | 2 | 2,226,545 | 2.41% |  |
| youtube video | 1 | 1,259,840 | 3.49% |  |
| AI tools | 2 | 512,609 | 3.01% |  |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| youtube video | 2 | 0 |
| youtube shorts | 3 | 0 |
