# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| youtube | unknown | ARE THEY ROBOTS OR REAL PEOPLE | 47,638,774 | 3.57% | VIRAL |
| youtube | unknown | I Live With Roaches (Ai Edition) 🪳 #ai #chatgpt #aiart | 24,843,184 | 1.37% | VIRAL |
| youtube | unknown | Van McCoy - The Hustle (Official Music Video) [HD] | 22,025,966 | 0.86% | VIRAL |
| youtube | unknown | Van McCoy & Pan's People » Do the Hustle (1975) | 21,529,692 | 0.92% | VIRAL |
| youtube | unknown | Meta AI is crazy 💀 | 16,078,743 | 1.52% | VIRAL |
| youtube | unknown | Satisfying Glass-Like Watermelon Bites 🍉✨ \| ASMR  (AI-Generated) | 12,215,056 | 0.80% | VIRAL |
| youtube | unknown | Real Life Vs AI | 12,034,591 | 0.42% | VIRAL |
| youtube | unknown | Van McCoy ft | 10,702,181 | 0.60% | VIRAL |
| youtube | unknown | Ai is getting scary | 7,847,273 | 2.59% | VIRAL |
| youtube | unknown | Hustle starring Adam Sandler \| Official Trailer \| Netflix | 7,637,535 | 1.27% | VIRAL |
| youtube | unknown | YoungBoy Never Broke Again - Hustle [Official Audio] | 7,227,462 | 0.82% | VIRAL |
| youtube | unknown | Van McCoy - The Hustle And Best Of - The Hustle (Original Mix) | 6,818,359 | 1.06% | VIRAL |
| youtube | unknown | AI Whistleblower: We Are Being Gaslit By AI Companies, They’re Hiding The Truth | 3,821,570 | 2.43% | VIRAL |
| youtube | unknown | Real or AI | 3,554,270 | 0.98% | VIRAL |
| youtube | unknown | Hustle \| he doesn't look like 22 😂 #shorts #edit #movie | 2,699,361 | 5.82% | VIRAL |
| youtube | unknown | Real life Vs AI | 2,230,629 | 2.87% | VIRAL |
| youtube | unknown | Is AI Hiding Its Full Power | 2,145,435 | 2.28% | VIRAL |
| youtube | unknown | These AI Cat Videos Are TOO Real to Be Fake #sora #funny #ai #cat | 2,064,962 | 1.55% | VIRAL |
| youtube | unknown | AI taught how to Act Human: Studying 📚 #chatgpt #ai #comedy | 1,536,316 | 5.47% | VIRAL |
| youtube | unknown | Boosie  Badazz - Hustle (official video) | 1,492,658 | 2.14% | VIRAL |
