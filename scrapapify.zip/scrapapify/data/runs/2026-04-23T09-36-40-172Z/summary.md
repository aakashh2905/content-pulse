# Codex Content System Run

Run ID: `2026-04-23T09-36-40-172Z`

## Inputs
- Skill location: C:\Users\Win 10\.codex\skills
- UI type: simple local web page
- Scraping method: Apify + OpenAI
- Output formats: markdown table, json
- Keywords: Hustle, AI
- Competitors: none
- Platforms: instagram, youtube
- Lookback: 7 days

## Outputs
- Scraped posts: 41
- Content buckets: 4
- Ranked topics: 3
- Script topic: AI
- Hooks generated: 5
