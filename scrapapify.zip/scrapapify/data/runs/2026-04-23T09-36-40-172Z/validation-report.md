# Validation Report

**Recommendation:** AI - Recommendation fell back to local heuristics after JSON parsing failed.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |
| Tool Spotlight | 5 | 11,197,690 | 3.36% |
| Tutorial / Walkthrough | 7 | 1,293,961 | 3.27% |
| Comparison / Alternatives | 2 | 1,186,900 | 4.09% |
| Trend / Commentary | 8 | 824,868 | 2.87% |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| AI | 12 | 5,596,591 | 3.42% | repeat viral signal |
| youtube video | 1 | 942,332 | 2.23% |  |
| Hustle | 9 | 657,500 | 3.06% | repeat viral signal |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| youtube shorts | 10 | 0 |
| youtube video | 12 | 0 |
