# Validation Report

**Recommendation:** content post - Recommendation generated from local score weights because OpenAI is not configured.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
