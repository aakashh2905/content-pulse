# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | oblvn.ai | They dropped a piano off a building to make a startup sound | 25,757 | 2.69% |  |
| instagram | nasha.natcha | Tried vibe coding for the first time 🪷✨
didn’t expect this many people to actually use it 🥹

Thank you so much 🫶🏻

ลอง vibe coding ครั้ง | 8,371 | 6.47% | VIRAL |
| instagram | __songyii | study time✨🌷

#study #studygrambr #student #studygrambr #trending | 6,267 | 0.05% |  |
