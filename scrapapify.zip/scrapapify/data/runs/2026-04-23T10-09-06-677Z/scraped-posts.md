# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | relatable_raj | 😂😂 | 209,974 | 5.63% | VIRAL |
| instagram | money_neva_sleeps | Nothing is free | 84,539 | 6.26% | VIRAL |
| instagram | gtvwithin | Season 1 is coming… and it’s bigger than anything NYC has ever seen | 51,169 | 32.75% | VIRAL |
| instagram | rk_kumar6164 | Himmat nahi harni kabhi | 36,984 | 13.96% | VIRAL |
| instagram | happyframex | “Pain was my teacher, struggle was my path… success became my destination | 33,606 | 10.64% | VIRAL |
| instagram | edielcosta | Essa plataforma digital, ainda permite você usar as melhores inteligência artificial do mercado gratuitamente | 33,597 | 3.56% |  |
| instagram | oblvn.ai | They dropped a piano off a building to make a startup sound | 25,825 | 2.69% |  |
| instagram | lazy_yachincat | 요즘 다들 경기 노잼이라고 느끼나요 | 23,083 | 4.60% |  |
| instagram | ai__halku__00 | #ai | 20,200 | 6.22% | VIRAL |
| instagram | aianback_ | Claude Code бесплатно — через AWS Startup Program можно выбить $1000-$100k кредитов | 16,329 | 2.70% |  |
| instagram | topcobraflex | Top G Aura Flexxing in Uzbekistan

#tateism #andrewtate #cobratate #tristantate #dreambigorgohome #hustle #motivationnation #hustlerclub #hu | 15,084 | 0.03% |  |
| instagram | _lavanya_goat_farm_ | “Built from hustle, heard in cash 🔊💵 | 14,181 | 0.01% |  |
| instagram | naturally.dutchess | Is this me or AI lol but body still tea #reel #fyp #ai #ootd | 9,477 | 12.29% | VIRAL |
| instagram | nabainc | AI can screen resumes | 7,691 | 7.00% | VIRAL |
| instagram | gulfem_languagelab | Artık farklarını anlayabiliyorum 🥹 @learna | 7,542 | 7.85% | VIRAL |
| instagram | _aayush_7x | 🫀👀 | 5,692 | 2.62% |  |
| instagram | sergey.chayka | 🥷

📹 @hksenia 

Силовой тренинг
Бодибилдинг тренер
Чемпион России по бодибилдингу
Фитнес клуб Красноярск

#hardwork
#mindset
#successminds | 4,570 | -0.02% |  |
| instagram | kfcino | Cost to get up in that bag like you was shopping at Aldi’s 

#Villain #OutNow #JohnCino #Hustle #Loyalty #Respect #Youtube #Newhiphop #newar | 2,361 | 14.65% | VIRAL |
| instagram | realshot.prompts | isso aqui NÃO parece IA…
e se você quer fazer igual,
me chama no direct com a palavra PROMPT 🔥

#ia
#inteligenciaartificial
#ai
#prompts
#m | 203 | 250.74% | VIRAL |
| instagram | creator.vaultt | Follow For More and Comment “READY” if you want to level up 🚀

#motivation #motivationreels #motivationalvideo #successmindset #selfgrowth  | 40 | 4132.50% | VIRAL |
