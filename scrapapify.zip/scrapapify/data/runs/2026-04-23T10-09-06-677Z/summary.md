# Codex Content System Run

Run ID: `2026-04-23T10-09-06-677Z`

## Inputs
- Skill location: C:\Users\Win 10\.codex\skills
- UI type: simple local web page
- Scraping method: Apify + OpenAI
- Run target: run-all
- Output formats: markdown table, json
- Keywords: Hustle, AI
- Competitors: none
- Platforms: instagram
- Lookback: 7 days

## Outputs
- Scraped posts: 20
- Content buckets: 4
- Ranked topics: 2
- Script topic: AI
- Hooks generated: 5
