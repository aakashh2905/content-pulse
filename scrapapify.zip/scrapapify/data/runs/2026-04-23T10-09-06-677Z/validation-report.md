# Validation Report

**Recommendation:** AI - Recommendation fell back to local heuristics after JSON parsing failed.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |
| Tutorial / Walkthrough | 1 | 84,539 | 6.26% |
| Tool Spotlight | 4 | 71,714 | 5.00% |
| Trend / Commentary | 2 | 44,077 | 23.35% |
| Results / Case Study | 3 | 25,253 | 5.34% |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| AI | 6 | 54,835 | 4.23% | repeat viral signal |
| Hustle | 4 | 51,575 | 15.90% | repeat viral signal |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| instagram reel | 10 | 64 |
