# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | emergenteck.in | Stop Building the Slow Way | 95 | 12.63% | VIRAL |
