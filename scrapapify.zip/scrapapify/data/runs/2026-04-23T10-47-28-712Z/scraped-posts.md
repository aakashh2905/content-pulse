# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | siddharthasintent | Is Buddhist prayer wishful thinking | 13,600 | 9.04% | VIRAL |
