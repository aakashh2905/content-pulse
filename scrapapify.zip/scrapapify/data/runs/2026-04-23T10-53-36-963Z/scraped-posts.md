# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | v.g_boss | Sweet #jamaica #jamaicanbeauty🇯🇲 #fypシ #yolo #happy | 55,745 | 3.73% |  |
| instagram | cezar.1807 | #happy #terasse #bully #🤣 | 27,463 | 9.88% | VIRAL |
| instagram | bhat_editz180 | Old memories 
public event turned chaotic at Hyderabad's Lulu Mall during the launch of a song from The Raja Saab | 21,644 | 0.00% |  |
| instagram | nutrifaty | Blog alteño chulo de bonito 🍃😍🫰🏻

Amo la tierra donde nací

#losaltos #jalisco #happy #love | 16,474 | 3.54% |  |
| instagram | manvarsureshp | #ramadhani_सदा_सहायते💫❤️👑🔰follow_me😎🕶️‼️रामाघणी‼️ #reelvideo #mamerufunction❤️🌼❤️ #happy | 15,700 | 4.04% |  |
| instagram | yamraj__.05 | 💯🔱

#viral #instagood #reels #india #instagram #gujju #hindi #gujarat #gunehgar #cow #trendingreels #trending #viratkohli #happy #king #vi | 9,469 | 0.04% |  |
| instagram | handsome_satz | #tvkfortn #tvkvijayofficial #tvkthalapathy_2026_❤️🔥 #vote #happy | 7,453 | 7.86% | VIRAL |
| instagram | _nithyamanoj___ | അമ്മുക്കുട്ടിയുടെ മേക്കപ്പ് കൂടുതൽ ആണോ #follow #style #smile #happy #babygirl | 5,157 | 10.57% | VIRAL |
| instagram | bible_quot_es | Matthew 6:33 | 4,846 | 19.69% | VIRAL |
| instagram | wendyzkaka | 好得意嘅散子包啊！

#vitasoy #音樂人 #維他奶 #維他奶造型小包 #minipouch | 985 | 33.30% | VIRAL |
