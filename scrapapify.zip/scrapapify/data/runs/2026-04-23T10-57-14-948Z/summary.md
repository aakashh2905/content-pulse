# Codex Content System Run

Run ID: `2026-04-23T10-57-14-948Z`

## Inputs
- Skill location: C:\Users\Win 10\.codex\skills
- UI type: dashboard
- Scraping method: Apify + OpenAI
- Run target: run-all
- Output formats: json
- Keywords: marketting
- Competitors: none
- Platforms: instagram
- Lookback: 15 days

## Outputs
- Scraped posts: 0
- Content buckets: 0
- Ranked topics: 0
- Script topic: content post
- Hooks generated: 5
