# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | imanoubou | I built en entire new website in less than a hour with one single prompt using @emergentlabs and I’m absolutely obsessed with how it turned  | 42,091 | 4.89% |  |
| instagram | nasha.natcha | 💻 Claude Design

Anthropic เพิ่งปล่อย Claude Design ออกมาเมื่อ Apr 17, 2026
มาดูกันว่ามันทำอะไรได้บ้าง ตั้งแต่ prototype, slide deck ไปจนถึ | 24,577 | 7.01% | VIRAL |
| instagram | __songyii | study time✨🌷

#study #studygrambr #student #studygrambr #trending | 6,651 | 0.06% |  |
