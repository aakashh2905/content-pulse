# Validation Report

**Recommendation:** aitools - Recommendation fell back to local heuristics after JSON parsing failed.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |
| Tutorial / Walkthrough | 1 | 42,091 | 4.89% |
| Trend / Commentary | 1 | 24,577 | 7.01% |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| aitools | 2 | 33,334 | 5.95% |  |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| instagram reel | 2 | 288 |
