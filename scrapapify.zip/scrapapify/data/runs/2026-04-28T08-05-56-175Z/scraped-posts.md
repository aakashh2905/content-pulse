# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | eleonora.viscardii | Dall’8 maggio anche se lo si desidera non si potranno più attivare i messaggi con la crittografia end-to-end come vi avevo già annunciato qu | 212,426 | 0.07% | VIRAL |
| instagram | ashley_linfox_ | I have been called “artificial intelligence” and I got some questions… | 162,582 | 7.07% | VIRAL |
| instagram | sabrina_ramonov | Follow and comment "COMMANDS" and I'll send you all of them 👇

19 ways to use Claude so well it feels illegal:

/btw - Chat while Claude is | 51,543 | 7.54% | VIRAL |
| instagram | cr.woner | Oq ngm sabe ngm estraga 🕺🏻🤫

#viralpost #visionario #lifestyle #marketing #marketingdigital Quem sou eu | 43,802 | 7.14% | VIRAL |
| instagram | taleofharsha | Launching the brand new series content 🔥
Know the importance of brands that actually ruling the world, 

Brading is not a subject it’s a ps | 37,522 | 5.14% | VIRAL |
| instagram | goluda.ai | DeepSeek just dropped V4 today | 27,317 | 3.12% |  |
| instagram | nickfreeediting | Baby Arteteca - Quando guida Lei #artetecaofficial #babyai #ai #artificialintelligence #baby | 24,069 | 4.65% |  |
| instagram | gyurzza | Моя кошка 🐈 сказала, что больше не хочет превращаться в дракона 🐉
Поэтому мы адаптировали этот тренд под себя 💙
Я стала ледяной королевой | 24,023 | 5.56% | VIRAL |
| instagram | ai.ustaxona | Tana yordam suramoqda #sinus #ai #fabrika #soglik | 21,727 | 1.33% |  |
| instagram | vanoutchy__regina | Jèn fi sa yo pa gen milyon followers
Yo pa viral chak jou
Men yo gen yon bagay anpil moun pa genyen

Yon fòmasyon ak yon sistèm 

Anvan mw t | 16,001 | 8.06% | VIRAL |
| instagram | falajoaobranco | Essa é a pergunta mais importante que eu posso fazer para ajudar a melhorar o seu marketing | 15,214 | 4.70% |  |
| instagram | dxfilms | DJ Khaled Ain’t Fat No More | 14,076 | 4.08% |  |
| instagram | peterjvoogd | The winners aren’t who you think | 12,476 | 5.30% | VIRAL |
| instagram | nyandia_gachago | Do likes pay your bills | 12,306 | 5.28% | VIRAL |
| instagram | nard2hard | If you can invest $300–$400 a month into your music career… you already ahead of most artists 💰

That’s not an expense, that’s your entry t | 12,216 | 6.13% | VIRAL |
| instagram | krypton_marketing | Pov: cuando trabajas en atención al cliente y ya no te importa nada 😅  #pov #bobesponja #marketing #marketingdigital #publicidad | 7,203 | 8.44% | VIRAL |
| instagram | djstarsoundlight | At dhumal 

#djdhumal #viralreels | 7,050 | 9.79% | VIRAL |
| instagram | psi.juba | rsrsrs 
#trend #divascorporativas #marketing #clt #corporategirl | 6,238 | 11.16% | VIRAL |
| instagram | nigel.green | How AI is impacting employment and efficiency in the workforce | 458 | 88.43% | VIRAL |
| instagram | sahilgupta.aigeek | Made a Hollywood Action Movie scene with ONLY AI Prompts 🤯

No cameras, no stunt doubles, and no massive VFX budget—just the power of gener | 223 | -0.45% |  |
