# Codex Content System Run

Run ID: `2026-04-28T08-05-56-175Z`

## Inputs
- Skill location: C:\Users\Win 10\.codex\skills
- UI type: simple local web page
- Scraping method: Apify + OpenAI
- Campaign: manual run
- Industry preset: Creator Brand / Education
- Team model: In-house marketing
- Primary goal: Build authority
- Run target: content-scraper
- Output formats: markdown table, json
- Keywords: AI Marketing
- Competitors: none
- Platforms: instagram
- Lookback: 7 days

## Outputs
- Scraped posts: 21
- Content buckets: 0
- Ranked topics: 0
- Industry brief: Build authority with explainers, frameworks, and transformation-led storytelling.
- Script topic: not generated
- Hooks generated: 0
- Local storage: written
- SharePoint storage: not_configured
