# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | eleonora.viscardii | Dall’8 maggio anche se lo si desidera non si potranno più attivare i messaggi con la crittografia end-to-end come vi avevo già annunciato qu | 212,426 | 0.07% | VIRAL |
| instagram | ashley_linfox_ | I have been called “artificial intelligence” and I got some questions… | 162,582 | 7.07% | VIRAL |
| instagram | sabrina_ramonov | Follow and comment "COMMANDS" and I'll send you all of them 👇

19 ways to use Claude so well it feels illegal:

/btw - Chat while Claude is | 51,543 | 7.54% | VIRAL |
| instagram | cr.woner | Oq ngm sabe ngm estraga 🕺🏻🤫

#viralpost #visionario #lifestyle #marketing #marketingdigital Quem sou eu | 43,802 | 7.14% | VIRAL |
| instagram | taleofharsha | Launching the brand new series content 🔥
Know the importance of brands that actually ruling the world, 

Brading is not a subject it’s a ps | 37,522 | 5.14% | VIRAL |
