# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | eleonora.viscardii | Dall’8 maggio anche se lo si desidera non si potranno più attivare i messaggi con la crittografia end-to-end come vi avevo già annunciato qu | 212,426 | 0.07% | VIRAL |
| instagram | cara_lilyyy | There is no where else I would rather be than spending time with my baby 🤍 

I didn’t want a huge change, just something a little extra to  | 67,965 | 3.77% |  |
| instagram | imanoubou | Comment AURA for the link to my workflow and the tool | 48,449 | 0.62% |  |
