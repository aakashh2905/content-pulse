# Script

Topic: **digitalmarketing**

## Voice Profile
```json
{
  "vocabulary": [
    "direct",
    "practical",
    "short-form"
  ],
  "sentenceLength": "short punchy lines",
  "structure": "[BEAT 1] -> [BEAT 2] -> [BEAT 3] -> [CTA]",
  "ctaStyle": "comment trigger",
  "languageMix": "English-first",
  "energy": "clear and instructional",
  "avoid": [
    "generic filler",
    "formal corporate phrasing"
  ]
}
```

## Script
[BEAT 1]
digitalmarketing is working right now because creators are packaging it with a clear outcome, not just a tool list. Keep the opening tight and say the result first in plain English.

[BEAT 2]
Show one concrete workflow, one mistake people make, and one proof point from the recent posts. Make each line short enough to say fast on camera.

[BEAT 3]
Close with the practical next step your viewer can copy today. Keep the energy clear and instructional and avoid sounding generic.

[CTA]
Keyword comment karo, main template bhej dunga.
