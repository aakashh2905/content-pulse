# Validation Report

**Recommendation:** digitalmarketing - Recommendation fell back to local heuristics after JSON parsing failed.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |
| Tutorial / Walkthrough | 1 | 67,965 | 3.77% |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| digitalmarketing | 1 | 67,965 | 3.77% |  |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| instagram reel | 1 | 20 |
