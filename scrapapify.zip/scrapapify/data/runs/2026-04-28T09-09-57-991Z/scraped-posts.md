# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | ashley_linfox_ | I have been called “artificial intelligence” and I got some questions… | 162,982 | 7.06% | VIRAL |
| instagram | dr.ai_robuu | Short #shorts #aivideo #ai | 109,108 | 2.34% | VIRAL |
| instagram | chinnii.ai | 😎#bold #aiart #artificialintelligence #digitalartreels #stablediffusion | 59,734 | 5.42% | VIRAL |
| instagram | sabrina_ramonov | Follow and comment "COMMANDS" and I'll send you all of them 👇

19 ways to use Claude so well it feels illegal:

/btw - Chat while Claude is | 51,679 | 7.53% | VIRAL |
| instagram | kari____kari | Because why not 🫶🏼@higgsfield | 47,581 | 21.89% | VIRAL |
| instagram | felicianizi | 🔥📡 Colorado uses AI-powered camera networks to detect wildfires within minutes | 46,400 | 1.44% |  |
| instagram | aeroo.verse | Tucked away in Veldhoven, Netherlands, ASML is one of the most powerful tech companies you've probably never heard of | 32,296 | 2.68% |  |
| instagram | health_hack17 | 健康のために最高の食品
#ai #健康 #健康 #食べ物 | 32,121 | 1.62% |  |
| instagram | gyurzza | Моя кошка 🐈 сказала, что больше не хочет превращаться в дракона 🐉
Поэтому мы адаптировали этот тренд под себя 💙
Я стала ледяной королевой | 31,065 | 5.22% | VIRAL |
| instagram | aymeric_carrez | Toi aussi tu te méfies de l'IA | 30,049 | 2.51% |  |
