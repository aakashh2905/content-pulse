# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | travelingnurselex | #artificialintelligence #chatgpt #polymarket | 261,449 | 8.10% | VIRAL |
| instagram | digitaltrends | Sony’s AI-powered robot, Ace, has achieved a significant robotics milestone by beating elite table tennis players in three out of five match | 223,105 | 2.83% | VIRAL |
| instagram | gormtheold25 | Grand Theft Auto: Vietnam (A | 217,791 | 11.09% | VIRAL |
| instagram | aiupdates.hub | AI just simulated a World War 3 scenario… and it went completely off script 😂🤖🔥

Imagine this | 186,514 | 0.49% | VIRAL |
| instagram | golf_kaab | "คืนชีพขุมพลัง Isuzu ให้กลับมาแวววาวอีกครั้ง กระบวนการล้างสนิมที่เปลี่ยนโลกเครื่องยนต์ไปเลย"
#สายงานช่างตัวถังและสี #carpainting #viralreels | 158,966 | 0.80% | VIRAL |
| instagram | netra_kutty | Mrunal | 136,264 | 2.34% | VIRAL |
| instagram | systaime | One image | 131,047 | 1.85% | VIRAL |
| instagram | dr.ai_robuu | Short #shorts #aivideo #ai | 121,869 | 2.32% | VIRAL |
| instagram | aisteppers | AI just claimed its first major victim 😳

Chegg, the $14 | 91,336 | 0.67% |  |
| instagram | sami.aly | Music generated with Suno 🎧
Video created using Kling 3 | 84,716 | 3.15% |  |
| instagram | graceblu | Antiques inspire AI art with Grace Blu | 77,382 | 1.34% |  |
| instagram | felicianizi | 🔥📡 Colorado uses AI-powered camera networks to detect wildfires within minutes | 72,898 | 1.37% |  |
| instagram | artificialintelligence.hub | This feels like something every San Andreas player already carried with them | 64,568 | 7.90% | VIRAL |
| instagram | artificialintelligence.hub | This feels like something every San Andreas player already carried with them | 64,558 | 7.90% | VIRAL |
| instagram | unsealed.files | The impact of AI infrastructure isn’t limited to the walls of data centers | 61,877 | 6.14% | VIRAL |
| instagram | chinnii.ai | 😎#bold #aiart #artificialintelligence #digitalartreels #stablediffusion | 59,735 | 5.41% | VIRAL |
| instagram | littlepuppy0720 | 95的油沒辦法加滿嗚嗚

#ai #博美 #搞笑 #柴犬 #可愛い | 56,937 | 3.91% |  |
| instagram | radar.militar | 🇺🇦🎥 𝗜𝗺𝗮𝗴𝗲𝗻𝘀: Centro de Operações Especiais 'Alfa' do Serviço de Segurança da Ucrânia (SBU)

#ia #artificialintelligence #drone #dr | 55,957 | 3.86% |  |
| instagram | musicinuasmr | 비빔밥🍚Mukbang ASMR🎧Cat ai video🐱
🙏Sound&Video by musicinU 뮤직인유 
🐱먼치킨 별사탕은 은 #bibimbap 맛있게 먹어요🤣
🐱별사탕의 의 긴 영상은 youtube 동영상으로 시청해주세요 🩷
🌍 | 53,518 | 2.13% |  |
| instagram | sabrina_ramonov | Follow and comment "COMMANDS" and I'll send you all of them 👇

19 ways to use Claude so well it feels illegal:

/btw - Chat while Claude is | 51,802 | 7.53% | VIRAL |
