# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | chanchal_iim | Whether you are prepping for MBA or already done with it | 117,726 | 4.75% | VIRAL |
| instagram | leadwithzoe | comment “claude” and i’ll dm you the exact skills I’m using to make some of the most insane ai videos on the internet right now | 79,620 | 10.99% | VIRAL |
| instagram | thatsgeno | I stopped waiting on opportunities…
and started stepping into them | 50,000 | 7.47% | VIRAL |
| instagram | thatsgeno | This the type of vision I see when I look at a brand | 22,606 | 9.44% | VIRAL |
| instagram | charlieautomates | Comment “AI Agent” for the Higgsfield Skills Repo Link

Claude just replaced your entire video workflow | 20,844 | 7.80% | VIRAL |
| instagram | mayijisesan | AI is huge, but ChatGPT opened our eyes to talking with these powerful machines | 18,548 | 2.83% |  |
| instagram | zack.mozes | Most businesses are asking the wrong question | 7,801 | 15.23% | VIRAL |
