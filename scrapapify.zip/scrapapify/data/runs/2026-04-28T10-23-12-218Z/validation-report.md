# Validation Report

**Recommendation:** aimarketing - Recommendation fell back to local heuristics after JSON parsing failed.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |
| Tool Spotlight | 3 | 71,965 | 6.19% |
| Tutorial / Walkthrough | 3 | 31,150 | 8.24% |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| aimarketing | 3 | 50,742 | 9.30% | repeat viral signal |
| AIMarketing | 3 | 52,373 | 5.13% | repeat viral signal |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| instagram reel | 6 | 1,941 |
