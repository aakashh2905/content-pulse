# Codex Content System Run

Run ID: `2026-04-28T10-24-10-329Z`

## Inputs
- Skill location: C:\Users\Win 10\.codex\skills
- UI type: simple local web page
- Scraping method: Apify + OpenAI
- Campaign: manual run
- Industry preset: Creator Brand / Education
- Team model: Agency team
- Primary goal: Build authority
- Run target: content-validator
- Output formats: markdown table, json
- Keywords: AIMARKETING
- Competitors: none
- Platforms: instagram
- Lookback: 30 days

## Outputs
- Scraped posts: 7
- Content buckets: 2
- Ranked topics: 2
- Industry brief: Build authority with explainers, frameworks, and transformation-led storytelling.
- Script topic: not generated
- Hooks generated: 0
- Local storage: written
- SharePoint storage: not_configured
