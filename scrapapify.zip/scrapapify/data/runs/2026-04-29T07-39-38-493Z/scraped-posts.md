# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | psi.juba | rsrsrs 
#trend #divascorporativas #marketing #clt #corporategirl | 383,301 | 7.33% | VIRAL |
| instagram | r_.iyaa | 💗 | 116,887 | 2.08% | VIRAL |
| instagram | ruvimkub | A device that greatly simplifies and speeds up the installation of crown molding | 115,838 | 1.46% | VIRAL |
