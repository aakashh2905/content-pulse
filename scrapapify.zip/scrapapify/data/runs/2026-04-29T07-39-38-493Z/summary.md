# Codex Content System Run

Run ID: `2026-04-29T07-39-38-493Z`

## Inputs
- Skill location: C:\\Users\\Win 10\\.codex\\skills
- UI type: simple local web page
- Scraping method: Apify + OpenAI
- Campaign: manual run
- Industry preset: Creator Brand / Education
- Team model: In-house marketing
- Primary goal: Build authority
- Output language: English
- Run target: run-all
- Output formats: markdown table, json
- Keywords: AI Marketing
- Competitors: none
- Platforms: instagram
- Lookback: 14 days

## Outputs
- Scraped posts: 3
- Content buckets: 2
- Ranked topics: 2
- Industry brief: Build authority with explainers, frameworks, and transformation-led storytelling.
- Script topic: trend
- Hooks generated: 5
- Local storage: written
- SharePoint storage: not_configured
