# Validation Report

**Recommendation:** trend - Recommendation fell back to local heuristics after JSON parsing failed.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |
| Trend / Commentary | 1 | 383,301 | 7.33% |
| Tool Spotlight | 1 | 116,887 | 2.08% |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| trend | 1 | 383,301 | 7.33% |  |
| trending | 1 | 116,887 | 2.08% |  |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| instagram reel | 2 | 481 |
