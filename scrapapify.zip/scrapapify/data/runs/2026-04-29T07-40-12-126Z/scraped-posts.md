# Scraped Posts

Mode: **live**

| Platform | Author | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- |
| instagram | dyslexiaadvice | What’s gone this time from Memory Trays 1 and 2 | 389,971 | 1.68% | VIRAL |
| instagram | ruvimkub | A device that greatly simplifies and speeds up the installation of crown molding | 115,838 | 1.46% | VIRAL |
| instagram | davisilvaot56 | Stop Guessing: Measure Wood Angles the Right Way #woodworking #tips #carpentry #ideas #diyproject | 93,354 | 0.69% |  |
