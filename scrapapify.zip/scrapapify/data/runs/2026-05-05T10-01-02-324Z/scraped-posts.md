# Scraped Posts

Mode: **live**

| Platform | Author | Region | Regional Fit | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- | --- | --- |
| instagram | mikusthedev | Global | global | CounterStrike IGL Simulator

#cs2 #cs2igl #rts #strategy #cs2rts | 656,115 | 2.16% | VIRAL |
| instagram | esinbruckner | Global | global | Einfaches Spiel – große Wirkung 💧

Viele Kinder lieben diese ruhigen Momente 🤍

Speichern für später ✨

#kidsplay #playtime #montessoriath | 156,213 | 1.09% | VIRAL |
| instagram | vip_craftsman | Global | global | ถอดลูกหมากคันชัก ( ลูกหมากแร็ค)
Remove the tie rod end

#Specialtools #Tools #Thailand #carservice | 136,281 | 0.35% | VIRAL |
| instagram | l.atelier.du.drainage | Global | global | Voici 3 astuces simples de kiné à intégrer facilement 👇

1️⃣ Monter sur la pointe des pieds

👉 Une vraie pompe veineuse naturelle grâce à  | 125,549 | 1.87% | VIRAL |
| instagram | beatricepotony | Global | global | L’attention, c’est la nouvelle monnaie 🎯
Tu es entrepreneur·e et tu veux gagner en visibilité | 119,488 | 4.99% | VIRAL |
| instagram | _basedment | Global | global | This could be the first video evidence of a destroyed Merkava Mk 4 by a FPV drone | 115,128 | 3.24% | VIRAL |
| instagram | toolmaster_store | Global | global | #tools | 111,858 | 0.53% | VIRAL |
| instagram | sebastien | Global | global | Comment "arcads" and ill send my workflow 👀 

Building full AI marketing campaigns used to take weeks, but now it takes minutes | 88,420 | 2.45% |  |
| instagram | gopalvermasir | Global | global | ⏰️15 Minute Exam English Strategy 🔥💯 SSC New Changes Sectional Timing | 82,198 | 5.19% | VIRAL |
| instagram | _elitemindz_ | Global | global | Japan is utilizing piezoelectric tiles to convert people's footsteps into electrical energy | 58,575 | 3.02% |  |
