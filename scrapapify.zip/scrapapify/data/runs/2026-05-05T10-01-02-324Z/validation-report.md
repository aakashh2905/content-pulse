# Validation Report

**Recommendation:** counterstrike simulator - Recommendation fell back to local heuristics after JSON parsing failed.

## Regional Market Lens
- Target region: Global
- Confidence: Global scan selected; no regional confidence scoring is required.
- Language recommendation: Keep English as the default unless the brand has a market-specific language strategy.
- Saturation: growing (64/100) - The trend has enough proof to use now, but still needs a distinct local angle.
- Opportunity: counterstrike simulator is the strongest global angle. Add a target region when you need local market decisions.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |
| Trend / Commentary | 3 | 285,934 | 4.11% |
| Tutorial / Walkthrough | 3 | 87,374 | 2.90% |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| counterstrike simulator | 1 | 656,115 | 2.16% |  |
| could destroyed | 1 | 115,128 | 3.24% |  |
| attention entrepreneur | 1 | 119,488 | 4.99% |  |
| workflow arcads | 1 | 88,420 | 2.45% |  |
| changes english | 1 | 82,198 | 5.19% |  |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| instagram reel | 6 | 155 |
