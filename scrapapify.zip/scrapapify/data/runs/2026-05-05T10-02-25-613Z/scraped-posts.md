# Scraped Posts

Mode: **live**

| Platform | Author | Region | Regional Fit | Hook | Views | ER | Flag |
| --- | --- | --- | --- | --- | --- | --- | --- |
| instagram | mikusthedev | Global | global | CounterStrike IGL Simulator

#cs2 #cs2igl #rts #strategy #cs2rts | 656,115 | 2.16% | VIRAL |
| instagram | emotional_life_squad | Global | global | Part-2 kal 8 baje \| Follow kar lo warna miss ho jayega

Agr sbhi superstar is reel pr comment kr de to me saari films dekhunga unki aNe vali | 271,344 | 0.94% | VIRAL |
| instagram | haniazayan2024 | Global | global | 😃😃#trendingreels #virelreels #sisterhood👭 #marketingstrategy | 252,006 | 1.92% | VIRAL |
| instagram | esinbruckner | Global | global | Einfaches Spiel – große Wirkung 💧

Viele Kinder lieben diese ruhigen Momente 🤍

Speichern für später ✨

#kidsplay #playtime #montessoriath | 156,213 | 1.09% | VIRAL |
| instagram | vip_craftsman | Global | global | ถอดลูกหมากคันชัก ( ลูกหมากแร็ค)
Remove the tie rod end

#Specialtools #Tools #Thailand #carservice | 136,281 | 0.35% | VIRAL |
| instagram | peronore | Global | global | Após o terrível acidente de Lauda em Nürburgring (1976), James Hunt foi um dos poucos que realmente se importou com o estado humano do adver | 133,408 | 6.27% | VIRAL |
| instagram | iamwaconzy | Global | global | Come closer waconzy flow  @oxladeofficial #waconzy #oxlade #afrobeats #portharcourtcity #phcity | 126,897 | 1.89% | VIRAL |
| instagram | iamwaconzy | Global | global | Come closer waconzy flow  @oxladeofficial #waconzy #oxlade #afrobeats #portharcourtcity #phcity | 126,897 | 1.89% | VIRAL |
| instagram | l.atelier.du.drainage | Global | global | Voici 3 astuces simples de kiné à intégrer facilement 👇

1️⃣ Monter sur la pointe des pieds

👉 Une vraie pompe veineuse naturelle grâce à  | 125,549 | 1.87% | VIRAL |
| instagram | beatricepotony | Global | global | L’attention, c’est la nouvelle monnaie 🎯
Tu es entrepreneur·e et tu veux gagner en visibilité | 119,488 | 4.99% | VIRAL |
