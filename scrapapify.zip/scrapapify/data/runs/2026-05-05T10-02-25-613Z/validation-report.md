# Validation Report

**Recommendation:** counterstrike simulator - Recommendation fell back to local heuristics after JSON parsing failed.

## Regional Market Lens
- Target region: Global
- Confidence: Global scan selected; no regional confidence scoring is required.
- Language recommendation: Keep English as the default unless the brand has a market-specific language strategy.
- Saturation: growing (60/100) - The trend has enough proof to use now, but still needs a distinct local angle.
- Opportunity: counterstrike simulator is the strongest global angle. Add a target region when you need local market decisions.

## Content Buckets
| Bucket | Posts | Avg Views | Avg ER |
| --- | --- | --- | --- |
| Trend / Commentary | 3 | 303,004 | 4.48% |

## Topic Rankings
| Topic | Posts | Avg Views | Avg ER | Signal |
| --- | --- | --- | --- | --- |
| counterstrike simulator | 1 | 656,115 | 2.16% |  |
| lauda james | 1 | 133,408 | 6.27% |  |
| attention entrepreneur | 1 | 119,488 | 4.99% |  |

## Format Rankings
| Format | Posts | Avg Share Signal |
| --- | --- | --- |
| instagram reel | 3 | 87 |
